let clients = [
    "Shake Shack",
    "Toast",
    "Computer Science Department",
    "Teacher's College",
    "Starbucks",
    "Subsconsious",
    "Flat Top",
    "Joe's Coffee",
    "Max Caffe",
    "Nussbaum & Wu",
    "Taco Bell",
];
let sales = [
    {
        "salesperson": "James D. Halpert",
        "client": "Shake Shack",
        "reams": 100
    },
    {
        "salesperson": "Stanley Hudson",
        "client": "Toast",
        "reams": 400
    },
    {
        "salesperson": "Michael G. Scott",
        "client": "Computer Science Department",
        "reams": 1000
    },
];

$(document).ready(function() {
    $( "#draggable" ).draggable({
        revert: function(droppable){
            return !droppable;
        }
    });

    $("#input-box1").autocomplete({
        source: function(request, response){
            var term = request.term;
            var matches = $.grep(clients, function(client){
                return client.toLowerCase().indexOf(term.toLowerCase()) !== -1;
            
            
        });
        if(matches.length === 0 && term !== ''){
            clients.push(term);
            matches.push(term);
        }
        response(matches);
        },
        messages: {
            noResults:'',
            results:'',
        }
    });
    function populatingExistingInfo(){
        var salesData= sales;
        const button = "delete";
        $.each(salesData, function(index, record){
            var $salesperson = $("<li>").text(record.salesperson);
            var $client = $("<li>").text(record.client);
            var $ream = $("<li>").text(record.reams);
            var $deletebutton = $("<li>").html("<button class='delete-button'>delete</button>");
            $(".record-area .salesperson ul").append($salesperson);
            $(".record-area .client ul").append($client);
            $(".record-area .reams ul").append($ream);
            $(".record-area .deletebutton ul").append($deletebutton);
    
        });
    }
    

    $("#submitButton").click(function(event) {
        submitForm(event);
    });

    function submitForm(event) {
        const defaultJason = "Jason Montoya";
        var client = $("#input-box1").val();
        var ream = $("#input-box2").val();
        var errorMessages = [];

        if(!client){
            errorMessages.push("Ummm excuse me! There's nothing in the client field >:|");
        }
        if(!ream){
            errorMessages.push("Stop playinnn, go back and input the number of reams >>:(");
        }else if (isNaN(ream) || parseInt(ream) <= 0) {
            errorMessages.push("POSITIVE INTEGERS ONLYYY");
        }
        
        // Clear previous error messages
        $("#error-messages").empty();
        
        if(errorMessages.length > 0){
            for(var i = 0; i < errorMessages.length; i++){
                $("#error-messages").append("<li>"+ errorMessages[i]+ "</li>");
            }

            // Focus on the first empty input field
            if(!client){
                $("#input-box1").focus();
            } else {
                $("#input-box2").focus();
            }
            return;
        }
        
        if (client && ream) {
            $(".salesperson ul").prepend("<li>" + defaultJason + "</li>");
            $(".client ul").prepend("<li>" + client + "</li>");
            $(".reams ul").prepend("<li>" + ream + "</li>");
            $(".deletebutton ul").prepend("<li>" + "<button class='delete-button'>delete</button>" + "</li>");

            $("#input-box1").val("");
            $("#input-box2").val("");

            
            $("#input-box1").focus();
        }
    }

    
    $("#input-box1, #input-box2").keydown(function(event) {
        if (event.keyCode === 13) {
            submitForm();
        }
    });

    populatingExistingInfo();


    $(".record-area").on("click", ".delete-button", function(){
        $(this).closest("span").siblings().find("ul li:first-child").remove();
        $(this).closest("li").remove();
    });




});


